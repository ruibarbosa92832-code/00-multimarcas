const products = window.PRODUCTS || [];
let cart = JSON.parse(localStorage.getItem("00_cart") || "[]");

const money = v => v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
const grid = document.getElementById("productGrid");
const search = document.getElementById("search");
const category = document.getElementById("category");

function save(){ localStorage.setItem("00_cart", JSON.stringify(cart)); renderCart(); }
function filtered(){
  const q = search.value.toLowerCase().trim();
  const c = category.value;
  return products.filter(p => (!q || p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q)) && (c==="Todos" || p.category===c));
}
function renderProducts(){
  const list = filtered();
  grid.innerHTML = list.length ? list.map(p=>`
    <article class="product-card">
      <div class="product-image"><img src="${p.image}" alt="${p.name}" loading="lazy"></div>
      <div class="product-info">
        <div class="product-brand">${p.brand}</div>
        <div class="product-name">${p.name}</div>
        <div class="product-price">${money(p.price)}</div>
        <button class="buy-btn" onclick="addToCart(${p.id})">Adicionar ao carrinho</button>
      </div>
    </article>`).join("") : `<div class="empty">Nenhum produto encontrado.</div>`;
}
function addToCart(id){
  const item = cart.find(x=>x.id===id);
  if(item) item.qty++;
  else cart.push({id,qty:1,size:"M"});
  save(); openCart();
}
function removeFromCart(id){ cart=cart.filter(x=>x.id!==id); save(); }
function changeQty(id,d){
  const x=cart.find(i=>i.id===id); if(!x)return;
  x.qty+=d; if(x.qty<=0) removeFromCart(id); else save();
}
function total(){return cart.reduce((s,x)=>{const p=products.find(p=>p.id===x.id);return s+(p?p.price*x.qty:0)},0)}
function renderCart(){
  document.getElementById("cartCount").textContent=cart.reduce((s,x)=>s+x.qty,0);
  const box=document.getElementById("cartItems");
  box.innerHTML=cart.length?cart.map(x=>{
    const p=products.find(p=>p.id===x.id);
    return `<div class="cart-item">
      <img src="${p.image}" alt="">
      <div><h4>${p.name}</h4><p>${money(p.price)} · Tamanho ${x.size}</p>
      <div class="qty"><button onclick="changeQty(${x.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${x.id},1)">+</button></div></div>
      <button class="icon-btn" style="font-size:20px" onclick="removeFromCart(${x.id})">×</button>
    </div>`}).join(""):`<div class="empty">Seu carrinho está vazio.</div>`;
  document.getElementById("cartTotal").textContent=money(total());
  document.getElementById("checkoutTotal").textContent=money(total());
}
function openCart(){document.getElementById("cartDrawer").classList.add("open");document.getElementById("overlay").classList.add("show")}
function closeCart(){document.getElementById("cartDrawer").classList.remove("open");document.getElementById("overlay").classList.remove("show")}
function openCheckout(){
  if(!cart.length){alert("Adicione pelo menos um produto ao carrinho.");return}
  closeCart(); document.getElementById("checkoutModal").classList.add("show"); document.getElementById("checkoutModal").setAttribute("aria-hidden","false");
}
function closeCheckout(){document.getElementById("checkoutModal").classList.remove("show");document.getElementById("checkoutModal").setAttribute("aria-hidden","true")}

document.getElementById("openCart").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("overlay").onclick=closeCart;
document.getElementById("checkoutBtn").onclick=openCheckout;
document.getElementById("closeCheckout").onclick=closeCheckout;
search.addEventListener("input",renderProducts); category.addEventListener("change",renderProducts);

document.querySelectorAll('input[name="payment"]').forEach(r=>r.addEventListener("change",e=>{
  document.getElementById("cardFields").classList.toggle("hidden",e.target.value!=="card");
}));

document.getElementById("checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=new FormData(e.target);
  const method=data.get("payment");
  if(method==="card"){
    alert("Checkout de cartão demonstrativo. Para cobrar de verdade, conecte um gateway de pagamento e suas credenciais.");
  } else {
    document.getElementById("pixResult").classList.remove("hidden");
    e.target.classList.add("hidden");
  }
});

function orderText(){
  const lines=cart.map(x=>{const p=products.find(p=>p.id===x.id);return `${x.qty}x ${p.name} — ${money(p.price*x.qty)}`});
  return `Olá! Quero fazer um pedido na 00 Multimarcas:\n${lines.join("\n")}\nTotal: ${money(total())}`;
}
document.getElementById("whatsappBtn").onclick=()=>{
  const url="https://wa.me/5598999856910?text="+encodeURIComponent(orderText());
  window.open(url,"_blank");
};
document.getElementById("copyOrder").onclick=async()=>{
  await navigator.clipboard.writeText(orderText());
  alert("Resumo copiado!");
};

renderProducts(); renderCart();
