# 00 Multimarcas — site

Abra `index.html` para visualizar a loja.

## O que já está pronto
- Catálogo responsivo com as 15 fotos enviadas.
- Busca e filtro por categoria.
- Carrinho com quantidade e total.
- Checkout com campos de cliente/endereço.
- Seleção de Pix ou cartão.
- Finalização pelo WhatsApp.
- Estrutura visual em preto/dourado, pensada para a 00 Multimarcas.

## Importante sobre pagamentos reais
O checkout incluído é uma interface funcional de demonstração. Para receber dinheiro de verdade, é necessário conectar um gateway de pagamento (por exemplo Mercado Pago, PagBank ou Stripe) e configurar as credenciais/conta da loja. Não coloque chaves secretas diretamente no JavaScript do navegador.

## Antes de publicar
1. Troque os preços de exemplo no `script.js`.
2. Confirme nomes, tamanhos e estoque.
3. Configure o gateway escolhido no servidor/serviço de checkout.
4. Troque Instagram/WhatsApp se necessário.
